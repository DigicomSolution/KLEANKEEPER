"use strict";
! function (p) {
	function m() {
		var e = {
			Android: function () {
				return navigator.userAgent.match(/Android/i)
			},
			BlackBerry: function () {
				return navigator.userAgent.match(/BlackBerry/i)
			},
			iOS: function () {
				return navigator.userAgent.match(/iPhone|iPad|iPod/i)
			},
			Opera: function () {
				return navigator.userAgent.match(/Opera Mini/i)
			},
			Windows: function () {
				return navigator.userAgent.match(/IEMobile/i)
			},
			any: function () {
				return e.Android() || e.BlackBerry() || e.iOS() || e.Opera() || e.Windows()
			}
		};
	}
	function v() {
		p(".xs-logo").each(function () {
			var e = p(this).children().clone(),
				t = p(".nav-brand");
			991 < p(window).width() ? 0 < t.children().length && t.children().remove() : 0 === t.children().length && t.append(e)
		})
	}

	function g() {
		var e = p(".bouble-slider-privew").outerHeight(!0),
			t = p(".bouble-slider-thumb .owl-stage-outer"),
			i = p(".bouble-slider-thumb .owl-stage-outer").outerWidth(!0),
			a = p(".bouble-slider-thumb .owl-stage");
		991 < p(window).width() && (t.css("height", e), a.css("width", i), a.css("height", e))
	}
	p.fn.myOwl = function (e) {
		var t = p.extend({
			items: 1,
			dots: !1,
			loop: !0,
			mouseDrag: !0,
			touchDrag: !0,
			nav: !1,
			autoplay:false,
			navText: ["", ""],
			margin: 0,
			stagePadding: 0,
			autoplayTimeout: 5e3,
			autoplayHoverPause: !0,
			navRewind: !1,
			responsive: {},
			animateOut: "",
			animateIn: "",
			center: "",
			merge: "",
			autoWidth: ""
		}, e);
		return this.owlCarousel({
			items: t.items,
			loop: t.loop,
			mouseDrag: t.mouseDrag,
			touchDrag: t.touchDrag,
			nav: t.nav,
			navText: t.navText,
			dots: t.dots,
			margin: t.margin,
			stagePadding: t.stagePadding,
			autoplay: t.autoplay,
			autoplayTimeout: t.autoplayTimeout,
			autoplayHoverPause: t.autoplayHoverPause,
			animateOut: t.animateOut,
			animateIn: t.animateIn,
			responsive: t.responsive,
			navRewind: t.navRewind,
			center: t.center,
			merge: t.merge,
			autoWidth: t.autoWidth
		})
    };
	var y = function () {
		var e = p(".xs-header");
		p(".xs-inner-banner .inner-banner").css("marginTop", e.outerHeight() / 2)
	};
	if (p.fn.scrollView = function () {
			return this.each(function () {
				p("html, body").animate({
					scrollTop: p(this).offset().top
				}, 1e3)
			})
		},
		p(window).on("load", function () {
			
			0 < p(".portfolio-slider_m").length && p(".portfolio-slider_m").myOwl({
				items: 3,
				margin: 35,
				nav: true,
				// autoplay: false,
				navigation: true,
				navigationText: [
					"<i class='icon-chevron-left icon-white'><</i>",
					"<i class='icon-chevron-right icon-white'>></i>"
				],
				navText: ['<i class="fa fa-angle-left" aria-hidden="true"></i>', '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve"><g><g><g><path d="M256,0C114.615,0,0,114.615,0,256s114.615,256,256,256s256-114.615,256-256S397.385,0,256,0z M256,480     C132.288,480,32,379.712,32,256S132.288,32,256,32s224,100.288,224,224S379.712,480,256,480z"></path> <path d="M219.2,116.8l-22.56,22.56L313.44,256L196.8,372.8l22.56,22.56l127.84-128c6.204-6.241,6.204-16.319,0-22.56L219.2,116.8  z"></path> </g></g></g></svg>'],
				responsive: {
					0: {
						items: 1.2,
						margin: 10
					},
					480: {
						items: 1.4						
					},
					768: {
						items: 2.4
					},
					1024: {
						items: 3.4
					}
				}
			}),
			0 < p(".cb-inner--list_m").length && p(".cb-inner--list_m").myOwl({
				items: 2,
				margin: 35,
				nav: true,
				// autoplay: false,
				navigation: true,
				navigationText: [
					"<i class='icon-chevron-left icon-white'><</i>",
					"<i class='icon-chevron-right icon-white'>></i>"
				],
				navText: ['<i class="fa fa-angle-left" aria-hidden="true"></i>', '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve"><g><g><g><path d="M256,0C114.615,0,0,114.615,0,256s114.615,256,256,256s256-114.615,256-256S397.385,0,256,0z M256,480     C132.288,480,32,379.712,32,256S132.288,32,256,32s224,100.288,224,224S379.712,480,256,480z"></path> <path d="M219.2,116.8l-22.56,22.56L313.44,256L196.8,372.8l22.56,22.56l127.84-128c6.204-6.241,6.204-16.319,0-22.56L219.2,116.8  z"></path> </g></g></g></svg>'],
				responsive: {
					0: {
						items: 2,
						marginright: 20
					},
					480: {
						items: 2,
						marginright: 20						
					},
					768: {
						items: 2,
						marginright: 20
					},
					1024: {
						items: 2,
						marginright: 20
					}
				}
			})
		}), 
		p(document).ready(function () {
			var i = p(".nav-sticky"),
			e = i.outerHeight(),
			a = p(document).scrollTop();
		p(window).on("load", function () {
			p(document).scrollTop() > e && (i.hasClass("sticky-header") ? i.removeClass("sticky-header") : i.addClass("sticky-header"))
		}), p(window).on("scroll", function () {
			var e = p(document).scrollTop(),
				t = p(".sticky-header");
			a < e ? t.addClass("sticky") : t.removeClass("sticky"), "top" === t.attr("data-scroll-to") && (e < a ? t.addClass("sticky") : t.removeClass("sticky")), 0 === e ? (i.removeClass("sticky-header"), t.removeClass("sticky")) : i.addClass("sticky-header"), a = p(document).scrollTop()
		})
			var u;
			new Swiper(".vertical-slider", {
				direction: "vertical",
				loop: !1,
				mousewheel: !1,
				pagination: {
					el: ".swiper-pagination",
					clickable: !0
				}
			});
			if (p("body").on("click", ".fullscreen_menu_tigger", function (e) {
					e.preventDefault(), p(this).toggleClass("open"), p(".offcanvas-menu-wraper").toggleClass("active"), p(".off-canvas-menu-area").toggleClass("nav-is-open")
				}),
				 
				0 < p(".portfolio-testimonial-slider").length) {
				var f = p(".portfolio-testimonial-slider");
				
			}
		}), 
		0 < p("#xs-map").length) {
	}
}(jQuery);

